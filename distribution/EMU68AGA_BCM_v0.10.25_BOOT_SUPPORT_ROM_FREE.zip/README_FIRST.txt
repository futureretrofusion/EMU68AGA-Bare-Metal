EMU68AGA BCM v0.10.25 — PUBLIC BOOT SUPPORT FILES ONLY
These configuration and Raspberry Pi firmware files match the locally
hardware-tested v0.10.22 boot-file configuration used with v0.10.25 kernel.

NOT A BOOTABLE DOWNLOAD BY ITSELF.
Deliberately NOT included: kernel8.img, Kickstart ROM, AmigaOS, AGS,
WHDLoad games, commercial ADFs. Do not advertise USB as functional in
a public firmware package without publishing a licence-compatible kernel.

For a PRIVATE local test, the owner uses an existing legitimately held
v0.10.25 USB-enabled kernel and their own Kickstart 3.1 ROM, named
kernel8.img and kick31.rom, alongside these files on the FAT32 partition.
This does not create the required AmigaOS/AGS partition; install separately.

Published USB binary requires licensing resolution: the AGA-PiStorm
chipset is GPL-2.0-only while USPi is GPL-3.0-or-later, and the current
private kernel statically links them.
