Future Retro Fusion EMU68AGA BCM v0.10.23 PUBLIC BOOT ALPHA
1. Copy CONTENTS of boot/ directory to first FAT32 boot partition on a Raspberry Pi 3 SD card.
2. Supply your own legal Amiga Kickstart 3.1 ROM, exactly named kick31.rom.
3. The AmigaOS/AGS disk is NOT included. Prepare an Emu68 compatible Amiga partition (MBR type 0x76) separately.
4. This PUBLIC kernel was compiled with FRF_USB_HOST=OFF pending review of USPi-related licensing. USB keyboard, mouse and joypad are not functional in this public variant. Therefore this is a boot test / evaluation package, not an input-ready distribution.
5. No physical Pi3A+ boot test of this variant has been performed. Keep your working boot SD backup.
The rainbow firmware splash is disabled; custom EMU68AGA BCM image is built into the kernel.
Author/contributor of standalone FRF integration: Future Retro Fusion. Upstream licences and notices apply.
