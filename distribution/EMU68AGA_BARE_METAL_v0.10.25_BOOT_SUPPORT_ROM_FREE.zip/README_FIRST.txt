EMU68AGA BARE METAL boot support files
Exact v0.10.22 boot configuration; licensed ROM and game ADF omitted.
NO KERNEL INCLUDED: not bootable without a separately obtained compatible kernel.
Do not publish USB-enabled kernel until GPL-2.0-only / USPi GPL-3.0+ combination is resolved.
