EMU68AGA BARE METAL USB-disabled diagnostic image
Exact v0.10.22 boot configuration; licensed ROM and game ADF omitted.
USB IS DISABLED; this diagnostic boot is NOT a usable USB keyboard/mouse release.
Do not publish USB-enabled kernel until GPL-2.0-only / USPi GPL-3.0+ combination is resolved.
